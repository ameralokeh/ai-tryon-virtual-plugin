/**
 * Automated Design Token Replacement Script
 * Replaces common hardcoded values with design tokens
 */

const fs = require('fs');
const path = require('path');

const cssFilePath = path.join(__dirname, 'modern-virtual-fitting.css');
let css = fs.readFileSync(cssFilePath, 'utf8');

// Define replacement mappings (order matters - more specific first)
const replacements = [
    // RGBA colors with opacity
    { from: /rgba\(231,\s*76,\s*60,\s*0\.2\)/g, to: 'var(--avf-error-light)' },
    { from: /rgba\(74,\s*144,\s*226,\s*0\.9\)/g, to: 'var(--avf-primary-overlay)' },
    { from: /rgba\(108,\s*117,\s*125,\s*0\.9\)/g, to: 'var(--avf-overlay-muted)' },
    { from: /rgba\(108,\s*117,\s*125,\s*1\)/g, to: 'var(--avf-overlay-muted)' },
    { from: /rgba\(255,\s*255,\s*255,\s*0\.95\)/g, to: 'var(--avf-overlay-light)' },
    { from: /rgba\(0,\s*0,\s*0,\s*0\.8\)/g, to: 'var(--avf-overlay-dark)' },
    
    // Specific sizes
    { from: /:\s*28px\b/g, to: ': var(--avf-text-4xl)' },
    { from: /:\s*36px\b/g, to: ': var(--avf-space-18)' },
    { from: /:\s*48px\b/g, to: ': var(--avf-space-24)' },
    { from: /:\s*64px\b/g, to: ': var(--avf-space-32)' },
    { from: /:\s*17px\b/g, to: ': var(--avf-text-lg)' }, // Close enough to 16px
];

// Apply replacements
let replacementCount = 0;
replacements.forEach(({ from, to }) => {
    const matches = css.match(from);
    if (matches) {
        replacementCount += matches.length;
        css = css.replace(from, to);
    }
});

// Write back to file
fs.writeFileSync(cssFilePath, css, 'utf8');

console.log(`✓ Replaced ${replacementCount} additional hardcoded values with design tokens`);
console.log(`✓ Updated file: ${cssFilePath}`);
