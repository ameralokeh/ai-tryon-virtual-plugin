/**
 * Property-Based Test for Design Token Coverage
 * Feature: mobile-responsive-ux, Property 2: Design Token Coverage
 * Validates: Requirements 2.1
 * 
 * This test verifies that all new CSS rules in mobile styles reference
 * CSS custom properties (--avf-*) rather than hardcoded values.
 */

const fs = require('fs');
const path = require('path');

// Read the CSS file
const cssFilePath = path.join(__dirname, 'modern-virtual-fitting.css');
const cssContent = fs.readFileSync(cssFilePath, 'utf8');

// Extract all CSS custom properties defined in :root
function extractDefinedTokens(css) {
    const rootMatch = css.match(/:root\s*{([^}]+)}/s);
    if (!rootMatch) return [];
    
    const tokens = [];
    const tokenRegex = /--(avf-[a-z0-9-]+):/g;
    let match;
    
    while ((match = tokenRegex.exec(rootMatch[1])) !== null) {
        tokens.push(match[1]);
    }
    
    return tokens;
}

// Extract all CSS rules and check for hardcoded values
function findHardcodedValues(css) {
    const violations = [];
    
    // Patterns for hardcoded values that should use tokens
    const patterns = [
        // Colors (hex, rgb, rgba) - excluding transparent and inherit
        { 
            regex: /:\s*(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\))(?!\s*\/\*\s*fallback)/g,
            type: 'color',
            exceptions: ['transparent', 'inherit', 'currentColor', 'white', 'rgba(255,255,255']
        },
        // Pixel values for spacing, radius, shadows (excluding 0px, 1px, 2px which are atomic)
        {
            regex: /:\s*([3-9]\d*px|[1-9]\d{2,}px)(?!\s*\/\*\s*exception)/g,
            type: 'spacing/size',
            exceptions: []
        },
        // Font sizes
        {
            regex: /font-size:\s*(\d+px)(?!\s*\/\*\s*exception)/g,
            type: 'font-size',
            exceptions: []
        },
        // Font weights (numeric)
        {
            regex: /font-weight:\s*([4-9]00)(?!\s*\/\*\s*exception)/g,
            type: 'font-weight',
            exceptions: []
        }
    ];
    
    // Split CSS into lines for better error reporting
    const lines = css.split('\n');
    
    lines.forEach((line, index) => {
        // Skip lines that are in :root definition
        if (line.includes(':root') || line.trim().startsWith('--avf-')) {
            return;
        }
        
        // Skip comments
        if (line.trim().startsWith('/*') || line.trim().startsWith('*')) {
            return;
        }
        
        patterns.forEach(pattern => {
            const matches = line.matchAll(pattern.regex);
            for (const match of matches) {
                const value = match[1] || match[0];
                
                // Check if this value is in exceptions
                const isException = pattern.exceptions.some(exc => 
                    value.includes(exc) || line.includes(exc)
                );
                
                if (!isException) {
                    violations.push({
                        line: index + 1,
                        content: line.trim(),
                        value: value,
                        type: pattern.type
                    });
                }
            }
        });
    });
    
    return violations;
}

// Property Test: Design Token Coverage
function testDesignTokenCoverage() {
    console.log('Running Property Test: Design Token Coverage');
    console.log('Feature: mobile-responsive-ux, Property 2');
    console.log('Validates: Requirements 2.1\n');
    
    // Extract defined tokens
    const definedTokens = extractDefinedTokens(cssContent);
    console.log(`✓ Found ${definedTokens.length} defined design tokens\n`);
    
    // Check for hardcoded values
    const violations = findHardcodedValues(cssContent);
    
    if (violations.length === 0) {
        console.log('✓ PASS: All CSS rules use design tokens');
        console.log('✓ No hardcoded values found in new mobile styles');
        return true;
    } else {
        console.log(`✗ FAIL: Found ${violations.length} hardcoded values that should use tokens:\n`);
        
        // Group violations by type
        const byType = violations.reduce((acc, v) => {
            acc[v.type] = acc[v.type] || [];
            acc[v.type].push(v);
            return acc;
        }, {});
        
        Object.entries(byType).forEach(([type, items]) => {
            console.log(`  ${type.toUpperCase()} violations (${items.length}):`);
            items.slice(0, 5).forEach(v => {
                console.log(`    Line ${v.line}: ${v.value}`);
                console.log(`      ${v.content.substring(0, 80)}...`);
            });
            if (items.length > 5) {
                console.log(`    ... and ${items.length - 5} more`);
            }
            console.log('');
        });
        
        return false;
    }
}

// Run the test
const passed = testDesignTokenCoverage();
process.exit(passed ? 0 : 1);
